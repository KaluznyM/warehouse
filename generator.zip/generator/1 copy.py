from dataclasses import asdict
from re import match
from unittest import result
import pandas as pd
import numpy as np
import random
import math
from faker import Faker
from datetime import datetime
import sys 

fake = Faker()

first_year = 2010
last_year = 2016
subjects = ['Sport', 'Biology', 'Chemistry', 'Geography', 'Physics', 'Mathematics', 'English', 'Polish', 'History', 'Informatics'] # 2 hours of each subject + 6 hours of A-level subject (extended subject)
classes = 32
grades = [1, 2, 2.5, 3, 3.5, 4, 4.5, 5, 6]
profile_name = ['math-phys', 'biol-chem', 'pol-his', 'mat-geo', 'mat-IT', 'mat-chem']
hours_beg = [7, 8, 9, 10, 11]
#hours_subject = ['1', '2', '5', '6', '7']
publishers = ['McMillan', 'McGregor', 'Pearson', 'WSIP', 'GWO']
subject_df = []
student_df = []
maturas_df = []
absences_df = []

studentsInClass = 50

teachersNumber = 50
#number of all subjects (courses) conducted in one year
subjectsNumber = len(subjects) * len(profile_name) * 4
#number of all students in a school in one year
studentsNumber = len(profile_name) * 4 * studentsInClass
#number of all classes in a school in one year
profilesNumber = len(profile_name) * 4

mark_len = results = pd.read_csv('data3/mark.csv')
mark_len = len(mark_len)
################################################################################################################################
################################################################################################################################
# df = pd.read_csv("data4/maturas2.csv")

# #zmiana ocen z matur
# row_count = len(df)
# x = 1
# while x < row_count:
#     df.at[x, 'grade'] = random.randint(40,100)
#     df.at[x, 'year'] = df.at[x, 'year'] + random.randint(1,5)
#     x = x + random.randint(50,100)

# df.to_csv("data4/maturas2.csv", index=False)

df = pd.read_csv("data4/absences2.csv")
row_count = len(df)
x = 1
while x < row_count:
    if(df.at[x, 'is_excused'] == 1):
        x = x + 1
    else:
        df.at[x, 'is_excused'] = 1
        x = x + random.randint(1,5)

df.to_csv("data4/absences2.csv", index=False)
################################################################################################################################
################################################################################################################################

#returns 2 subjects that are extended on given profile
def check_profile(profile):
    tab = []
    if(profile=='math-phys'):
        tab = ['Mathematics', 'Physics']
    elif(profile=='biol-chem'):
        tab = ['Biology', 'Chemistry']
    elif(profile=='pol-his'):
        tab = ['Polish', 'History']
    elif(profile=='mat-geo'):
        tab = ['Mathematics', 'Geography']
    elif(profile=='mat-IT'):
        tab = ['Mathematics', 'Informatics']
    elif(profile=='mat-chem'):
        tab = ['Mathematics', 'Chemistry']
    return tab

#matura
def make_matura(student_ID, profile_name, year):
    fake_maturas = []
    subject_num = np.random.choice([0,1,2,3,4,5])
    x = 2
    date1 = '-07-04'
    date1 = str(year) + date1
    year = datetime.strptime(date1, '%Y-%m-%d')
    subject_m = []
    if subject_num == 0:
        subject_num = 1
    if subject_num==1:
        subject_m.append(str(subjects.index(np.random.choice(check_profile(profile_name))) + 10 * math.floor(student_ID / studentsInClass)))
    elif subject_num>=2:
        subjects_m = check_profile(profile_name)
        subject_m.append(str(subjects.index(subjects_m[0]) + 10 * math.floor(student_ID / studentsInClass)))
        subject_m.append(str(subjects.index(subjects_m[1]) + 10 * math.floor(student_ID / studentsInClass)))
    while x < subject_num:
        subject = np.random.choice(subjects)
        if str(subjects.index(subject)) not in subject_m and subject != 'Sport':
            subject_m.append(str(subjects.index(subject) + 10 * math.floor(student_ID / studentsInClass)))
            x = x + 1
    for a in range(subject_num - 1):
        m_result = round(np.random.normal(loc = 73, scale = 5))
        if len(subject_m)>5:
            fake_maturas.append([m_result, year, student_ID, subject_m])
        else:
            fake_maturas.append([m_result, year, student_ID, subject_m[a]])
    return fake_maturas


#students
def make_students(class_ID, profile_name, year):  
    global maturas_df
    fake_students = []
    for x in range(studentsInClass):
        student_ID = x+1 + (class_ID-1) * studentsInClass
        Name = fake.first_name()
        Surname = fake.last_name()
        fake_students.append([student_ID, Name, Surname, class_ID])
        maturas_df.extend(make_matura(student_ID = student_ID, profile_name = profile_name, year = year))
        
    return fake_students

#teachers
def make_teachers(num):  
    global subject_df
    fake_teachers = []
    subject_num = 0
    current_subject = 0
    enough = 0
    rotation = 1
    for x in range(num): 
        t_hours = 0
        teacher_ID = x+1
        Name = fake.first_name()
        Surname = fake.last_name()
        fake_teachers.append([teacher_ID, Name, Surname])
            
    return fake_teachers

def make_absences(num, class_ID, year):
    fake_absences = []
    absence_date1 = '-09-01'
    absence_date2 = '-06-20'
    absence_date1 = str(year) + absence_date1
    absence_date2 = str(year+1) + absence_date2
    for x in range(num):
        student_ID = studentsInClass * (class_ID-1) + random.randint(1,studentsInClass)
        subject_ID = 10 * (class_ID-1) + random.randint(1,10)
        date = fake.date_between_dates(datetime.strptime(absence_date1, '%Y-%m-%d'), datetime.strptime(absence_date2, '%Y-%m-%d'))
        is_excused = random.randint(0,1)
        fake_absences.append([date, is_excused, student_ID, subject_ID ])
    return fake_absences


def make_book():
    fake_books = []
    for x in range(len(publishers)):
        publisher = publishers[x%len(publishers)]
        for y in range(len(subjects)):
            book_ID = y+1 + 10 * (x)
            subject = subjects[y%len(subjects)]
            name = subject + ' ' + publisher
            fake_books.append([book_ID, name, publisher])
    return fake_books

books_df = pd.DataFrame(make_book())
books_df.head()


def make_subject(id, profile_name, year):
    global classes
    classes = 0
    fake_subjects = []
    book_ID = 1
    tab = check_profile(profile_name)
    for x in range(10):
        subject_ID = x + 1 + 10 * (id-1)
        subject = subjects[x%10]
        if (subject == tab[0] or subject == tab[1]):
            hours = np.random.choice([6,7,8])
        else:
            hours = np.random.choice([1,2,3])
        classes = classes + hours
        class_ID = id
        book_ID = subject + ' ' + np.random.choice(publishers)
        if subject == 'Sport':
            teacher_ID = 37
        else:
            teacher_ID = (subjects.index(subject)-1) * 4 + (year % 4) + 1
        fake_subjects.append([subject_ID, hours, subject, class_ID, book_ID, teacher_ID])
    return fake_subjects


#class
def make_classes(num):  
    global subject_df
    global student_df
    global classes
    fake_classes = []
    prob = [0.05, 0.65, 0.20, 0.05, 0.05]
    for x in range(num):
        Monday_beg = np.random.choice(hours_beg, p = prob)
        Tuesday_beg = np.random.choice(hours_beg, p = prob)
        Thursday_beg = np.random.choice(hours_beg, p = prob)
        Wednesday_beg = np.random.choice(hours_beg, p = prob)
        Friday_beg = np.random.choice(hours_beg, p = prob)
        class_ID = x+1 + 66
        profile = profile_name[x % 6]
        begin_year = first_year + math.floor(x / 6)
        if begin_year > last_year:
            break

        subject_df.extend(make_subject(id = class_ID, profile_name = profile, year = begin_year))
        student_df.extend(make_students(class_ID = class_ID, profile_name = profile, year = begin_year + 4))
        absences_df.extend(make_absences(num = 10000, class_ID = class_ID, year = begin_year))

        rand = []
        for i in range(4):
            rand.append(np.random.choice([5, 6, 7, 8], p = [0.05, 0.50, 0.35, 0.10]))
        Monday_end = Monday_beg + rand[0]
        Tuesday_end = Tuesday_beg + rand[1]
        Wednesday_end = Thursday_beg + rand[2]
        Thursday_end = Thursday_beg + rand[3]
        Friday_end = Friday_beg + classes - sum(rand)
        fake_classes.append([Monday_beg, Tuesday_beg, Wednesday_beg, Thursday_beg, Friday_beg, class_ID, begin_year, 
                            profile, Monday_end, Tuesday_end, Wednesday_end, Thursday_end, Friday_end, classes])

    return fake_classes

teacher_df = make_teachers(num=(len(subjects)-1)*4 + 1)

def make_mark():
    fake_marks = []
    mark_id = 1
    student_ID = 0
    subject_ID = 0

    for a in range(len(classes_df)): #generate grade for each class
        for b in range(4): #generate grades for each year
            if first_year + math.floor(a/6) + b > last_year:
                break
            for c in range(len(subjects)): # generate for each subject
                mark_num = random.randint(4,7)
                for y in range(studentsInClass): # generate grades for each student
                    for x in range(mark_num): #generate mark_num grades
                        mark = np.random.choice(grades, p = [0.01, 0.02, 0.02, 0.1, 0.15, 0.3, 0.2, 0.15, 0.05])
                        group_work = np.random.choice([1, 0],p = [0.7, 0.3])
                        year = first_year + math.floor(a/6) + b
                        end1 = '-01-01'
                        end2 = '-01-01'
                        date1 = str(year) + end1
                        date2 = str(year+1) + end2
                        date = fake.date_between_dates(datetime.strptime(date1, '%Y-%m-%d'), datetime.strptime(date2, '%Y-%m-%d'))
                        mark_ID = mark_id
                        mark_id = mark_id + 1 
                        student_ID = y + 1 + a * studentsInClass
                        subject_ID = c + 1 + a * 10
                        fake_marks.append([mark, group_work, year, mark_ID + mark_len, student_ID, subject_ID, date])
    return fake_marks
def make_e_teacher():
    num = len(teacher_df)
    e_teachers = []
    for x in range(num):
        teacher_ID = teacher_df[x][0]
        school_beg = fake.date_between_dates(datetime.strptime('2005-08-01', '%Y-%m-%d'), datetime.strptime('2010-08-31', '%Y-%m-%d'))
        if teacher_ID == 37:
            subject = subjects[0]
        else:
            subject = subjects[math.floor((teacher_ID-1)/4) + 1]
        if random.randint(1,10) == 1:
            work_beg = school_beg
        else:
            work_beg = fake.date_between_dates(datetime.strptime('1990-01-01', '%Y-%m-%d'), school_beg)
        e_teachers.append([teacher_ID, school_beg, subject, work_beg])
    return e_teachers


def make_e_students():
    num = len(student_df)
    e_students = []
    for x in range(num):
        student_ID = x + 3300 + 1
        class_ID = x + 66
        school_begin = first_year + math.floor(student_ID/180)
        birth_year = school_begin - 15
        end1 = '-01-01'
        end2 = '-12-31'
        date1 = str(birth_year) + end1
        date2 = str(birth_year) + end2
        birth_date = fake.date_between_dates(datetime.strptime(date1, '%Y-%m-%d'), datetime.strptime(date2, '%Y-%m-%d'))
        post_code = fake.postcode()
        house_number = fake.building_number()
        street = fake.street_name()
        psychological_help = random.randint(0,1)
        e_students.append([student_ID, birth_date, school_begin, post_code, house_number, street, psychological_help])
    return e_students


classes_df = pd.DataFrame(make_classes(num=50))
classes_df.head()

maturas_df = pd.DataFrame(maturas_df)
maturas_df.head()

absences_df = pd.DataFrame(absences_df)
absences_df.head()

mark_df = pd.DataFrame(make_mark())
mark_df.head()


subject_df = pd.DataFrame(subject_df)
subject_df.head()

student_df = pd.DataFrame(student_df)
student_df.head()

students_excel = pd.DataFrame(make_e_students())
students_excel.head()



student_df.to_csv('data4/student.csv', mode='a', header=False, index = False)
classes_df.to_csv('data4/classes.csv', mode='a', header=False, index = False)
mark_df.to_csv('data4/mark.csv', mode='a', header = False, index = False)
maturas_df.to_csv('data4/maturas2.csv', mode='a', header=False, index = False)
subject_df.to_csv('data4/subject.csv', mode='a', header=False, index = False)
absences_df.to_csv('data4/absences2.csv', mode='a', header=False, index = False)
students_excel.to_csv('data4/students_e.csv', mode='a', header=False, index = False)


original_stdout = sys.stdout 





